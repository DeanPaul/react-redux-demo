import React, {Component, PropTypes} from 'react';

class MessageSearchBar extends Component {


    render() {
        return (
            <div>MessageSearchBar</div>
        );
    }
}

MessageSearchBar.propTypes = {};

export default MessageSearchBar;
