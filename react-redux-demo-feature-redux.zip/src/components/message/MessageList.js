import React, {Component, PropTypes} from 'react';

class MessageList extends Component {


    render() {
        return (
            <div>MessageList</div>
        );
    }
}

MessageList.propTypes = {};

export default MessageList;
