import React, {Component, PropTypes} from 'react';

class MessageFooter extends Component {


    render() {
        return (
            <div>MessageFooter</div>
        );
    }
}

MessageFooter.propTypes = {};

export default MessageFooter;
