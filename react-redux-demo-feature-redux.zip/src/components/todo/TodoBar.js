import React, {Component, PropTypes} from 'react';

class TodoBar extends Component {


    render() {
        return (
            <div>TodoBar</div>
        );
    }
}

TodoBar.propTypes = {};

export default TodoBar;
