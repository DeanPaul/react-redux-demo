import React, {Component, PropTypes} from 'react';

class TodoList extends Component {


    render() {
        return (
            <div>TodoList</div>
        );
    }
}

TodoList.propTypes = {};

export default TodoList;
